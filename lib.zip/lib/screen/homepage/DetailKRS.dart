import 'package:academic_mobile/screen/homepage/HomeScreen.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class Detailkrs extends StatefulWidget {
  const Detailkrs({super.key});

  @override
  State<Detailkrs> createState() => _DetailkrsState();
}

class _DetailkrsState extends State<Detailkrs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 45, 51, 87),
      body: SafeArea(
        child: Column(
          children: [
            // Top Bar
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => HomeScreen()),
                      );
                    },
                  ),
                  const Text(
                    'Detail KRS',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Text
                      Text(
                        'Detail kartu rencana studi',
                        style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                      ),
                      Divider(height: 30, thickness: 2),
                      SizedBox(height: 20),
                      // Other components
                      Table(
                        border: TableBorder.all(color: Colors.grey),
                        columnWidths: const {
                          0: FlexColumnWidth(1),
                          1: FlexColumnWidth(2),
                          2: FlexColumnWidth(4),
                          3: FlexColumnWidth(1),
                        },
                        children: [
                          _buildTableRow('No', 'Kode MK', 'Mata Kuliah', 'SKS',
                              isHeader: true),
                          _buildTableRow('1', '210702-12', 'Data Mining', '2'),
                          _buildTableRow('2', '210702-13', 'Rekayasa Web', '3'),
                          _buildTableRow(
                              '3', '210702-14', 'Sistem Operasi', '3'),
                        ],
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            _generatePdf();
                          },
                          child: Text('Cetak KRS'),
                          style: ElevatedButton.styleFrom(
                            padding: EdgeInsets.symmetric(
                                horizontal: 50, vertical: 15),
                            backgroundColor: Color.fromARGB(255, 45, 51, 87),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _generatePdf() async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(
              'Kartu Rencana Studi',
              style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
            ),
            pw.Divider(),
            pw.SizedBox(height: 20),
            pw.Table(
              border: pw.TableBorder.all(),
              children: [
                _buildPdfTableRow('No', 'Kode MK', 'Mata Kuliah', 'SKS',
                    isHeader: true),
                _buildPdfTableRow('1', '210702-12', 'Data Mining', '2'),
                _buildPdfTableRow('2', '210702-13', 'Rekayasa Web', '3'),
                _buildPdfTableRow('3', '210702-14', 'Sistem Operasi', '3'),
              ],
            ),
          ],
        ),
      ),
    );

    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  pw.TableRow _buildPdfTableRow(
      String no, String kodeMk, String mataKuliah, String sks,
      {bool isHeader = false}) {
    return pw.TableRow(
      children: [
        pw.Padding(
          padding: const pw.EdgeInsets.all(8.0),
          child: pw.Text(no,
              style: pw.TextStyle(
                  fontWeight:
                      isHeader ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ),
        pw.Padding(
          padding: const pw.EdgeInsets.all(8.0),
          child: pw.Text(kodeMk,
              style: pw.TextStyle(
                  fontWeight:
                      isHeader ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ),
        pw.Padding(
          padding: const pw.EdgeInsets.all(8.0),
          child: pw.Text(mataKuliah,
              style: pw.TextStyle(
                  fontWeight:
                      isHeader ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ),
        pw.Padding(
          padding: const pw.EdgeInsets.all(8.0),
          child: pw.Text(sks,
              style: pw.TextStyle(
                  fontWeight:
                      isHeader ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ),
      ],
    );
  }

  TableRow _buildTableRow(
      String no, String kodeMk, String mataKuliah, String sks,
      {bool isHeader = false}) {
    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(no,
              style: TextStyle(
                  fontWeight: isHeader ? FontWeight.bold : FontWeight.normal)),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(kodeMk,
              style: TextStyle(
                  fontWeight: isHeader ? FontWeight.bold : FontWeight.normal)),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(mataKuliah,
              style: TextStyle(
                  fontWeight: isHeader ? FontWeight.bold : FontWeight.normal)),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(sks,
              style: TextStyle(
                  fontWeight: isHeader ? FontWeight.bold : FontWeight.normal)),
        ),
      ],
    );
  }
}
