import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:academic_mobile/screen/welcomescreen/LoginScreen.dart'; // Make sure to import the LoginScreen

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isDataLoaded = false;
  File? _profileImage;
  File? _imageFile;
  bool _isLoading = false;

  final user = FirebaseAuth.instance.currentUser!;

  String _name = "";
  String _nim = "";
  String _email = "";
  String _phone = "";

  // Controllers for the TextFields
  TextEditingController _nameController = TextEditingController();
  TextEditingController _nimController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();

  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    try {
      // Check if the user is logged in with Google or Email
      if (user.providerData
          .any((provider) => provider.providerId == 'google.com')) {
        // Google Login
        setState(() {
          _name = user.displayName ?? "Name not found";
          _email = user.email ?? "Email not found";
          _isDataLoaded = true;
          _nameController.text = _name; // Set name controller with user name
        });
      } else {
        // Email/Password Login
        final docSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (docSnapshot.exists) {
          setState(() {
            _name = docSnapshot['name'] ?? "Name not found";
            _nim = docSnapshot['nim'] ?? "NIM not found";
            _email = docSnapshot['email'] ?? "Email not found";
            _phone = docSnapshot['phone'] ?? "Phone not found";
            _isDataLoaded = true;
            _nameController.text =
                _name; // Set name controller with fetched name
            _nimController.text = _nim; // Set NIM controller with fetched NIM
            _phoneController.text = _phone;
          });
        } else {
          print('Document not found.');
        }
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
        _profileImage = _imageFile; // Update profile image
      });

      // Save to Firestore (optional if you want to save path or file URL)
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(FirebaseAuth.instance.currentUser?.uid)
            .update({'profileImage': pickedFile.path});
      } catch (e) {
        print('Error updating profile image: $e');
      }
    }
  }

  Future<void> _logout() async {
    try {
      setState(() {
        _isLoading = true;
      });

      await _googleSignIn.signOut();
      await FirebaseAuth.instance.signOut();

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const LoginScreen(),
        ),
      );
    } catch (e) {
      print("Error during logout: $e");
      Fluttertoast.showToast(
        msg: "Logout failed. Please try again!",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _saveChanges() async {
    try {
      String updatedName = _nameController.text;
      String updatedNim = _nimController.text;
      String updatePhone = _phoneController.text;

      // Update Firestore with new name and NIM
      await FirebaseFirestore.instance
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser?.uid)
          .update({
        'name': updatedName,
        'nim': updatedNim,
        'phone': updatePhone,
      });

      setState(() {
        _name = updatedName;
        _nim = updatedNim;
        _phone = updatePhone;
      });

      Fluttertoast.showToast(
        msg: "Profile updated successfully!",
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );
    } catch (e) {
      print("Error saving changes: $e");
      Fluttertoast.showToast(
        msg: "Error saving changes, please try again.",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasData) {
          return Scaffold(
            backgroundColor: const Color.fromRGBO(45, 51, 87, 1),
            body: SafeArea(
              child: Container(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.logout, color: Colors.white),
                            onPressed: _logout,
                          ),
                          const Text(
                            'Profile',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.notifications,
                                color: Colors.white),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),

                    // Profile image with edit icon
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 160,
                          height: 160,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(
                                    _profileImage!,
                                    fit: BoxFit.cover,
                                  )
                                : Image.asset(
                                    'assets/images.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const CircleAvatar(
                                        radius: 60,
                                        backgroundColor: Colors.grey,
                                        child: Icon(Icons.person,
                                            size: 60, color: Colors.white),
                                      );
                                    },
                                  ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 10,
                          child: GestureDetector(
                            onTap: _pickImage,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                              padding: const EdgeInsets.all(8),
                              child: const Icon(
                                Icons.edit,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 32),

                    _isDataLoaded
                        ? Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(24),
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(40)),
                              ),
                              child: Column(
                                children: [
                                  TextFormField(
                                    controller: _nameController,
                                    decoration: InputDecoration(
                                      labelText: 'Name',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  // Show Nim only if login with email
                                  if (_nim.isNotEmpty)
                                    TextFormField(
                                      controller: _nimController,
                                      decoration: InputDecoration(
                                        labelText: 'NIM',
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(30),
                                        ),
                                      ),
                                    ),
                                  const SizedBox(height: 24),
                                  TextFormField(
                                    readOnly: true,
                                    initialValue: _email,
                                    decoration: InputDecoration(
                                      labelText: 'Email',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  TextFormField(
                                    controller: _phoneController,
                                    decoration: InputDecoration(
                                      labelText: 'Phone',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  ElevatedButton(
                                    onPressed: _saveChanges,
                                    child: const Text('Save Changes'),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : const Center(child: CircularProgressIndicator()),
                  ],
                ),
              ),
            ),
          );
        } else {
          return const LoginScreen(); // Display login screen if not logged in
        }
      },
    );
  }
}
