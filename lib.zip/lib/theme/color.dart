import 'package:flutter/material.dart';

class AppColor{
  static const primary = Color(0xFF2D3357);
  static const secondary = Color(0xFF59608B);
  static const grey = Color.fromARGB(255, 229, 227, 227);
}